window.ff.Site = "http://kaoriha.org/kouchabutton/";
window.ff.Title = "紅茶ボタン";
