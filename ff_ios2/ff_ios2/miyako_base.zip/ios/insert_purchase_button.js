(function() {
	
function updatePrice() {
	window.Purchase.UpdatePrice ();
	$('#purchase_button').html(window.Purchase.Price);
}

$(document).ready(function() {
	$('#content').append('<a id="purchase_button" href="#" onClick="window.Purchase.Purchase();">---</a>');
});

document.addEventListener('deviceready', function() {
	updatePrice();
	setInterval(updatePrice, 1000);
}, false);

})();