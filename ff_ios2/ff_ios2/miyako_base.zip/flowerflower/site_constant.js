window.ff.Site = "http://kaoriha.org/miyako/";
window.ff.Title = "鄙の姫、宮処の巫女、余所者の嫁";
