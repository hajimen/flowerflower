(function() {
window.Purchase = {};
window.Purchase.price = "---";

function updatePrice() {
	cordova.exec(function(p) { window.Prurchase.price = p; }, null, "org.kaoriha.phonegap.plugins.purchase",
			"price", []);
}
window.Purchase.UpdatePrice = updatePrice;

function buy() {
	cordova.exec(null, null, "org.kaoriha.phonegap.plugins.purchase",
			"purchase", []);
}
window.Purchase.Purchase = buy;

})();
