document.write("<script src='../jquery-1.6.2.min.js'></script>"
		+ "<script src='../design/spin.min.js'></script>"
		+ "<script src='../ios/cordova.ios.js'></script>"
		+ "<script src='../ios/scaleChanger.js'></script>"
		+ "<script src='../ios/purchase.js'></script>"
		+ "<script src='../design/design_base.js'></script>"
		+ "<script src='../tsume/tsume.js'></script>"
		+ "<script src='../flowerflower/site_constant.js'></script>"
		+ "<script src='../ios/insert_purchase_button.js'></script>"
		+ '<link rel="stylesheet" href="../ios/insert_purchase_button.css" />'
		);
