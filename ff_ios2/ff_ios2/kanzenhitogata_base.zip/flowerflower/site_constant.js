window.ff.Site = "http://kaoriha.org/kanzenhitogara/";
window.ff.Title = "完全人型";
